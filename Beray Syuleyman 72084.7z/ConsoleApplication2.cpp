
#include <iostream>
using namespace std;
int main()
{
    double n; cin >> n;
	
	for (double i = n - 0.5; i > 0; i-=0.5)
	{
		cout << i << " ";
	}
    
}
