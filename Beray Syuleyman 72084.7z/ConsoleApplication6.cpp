#include <iostream>
using namespace std;

int main()
{
    int n; cin >> n;
	int product = 1;
	if (n == 0 || n == 1)
	{
		cout << 1;
	}
	else
	{
		
		while (true)
		{
			product *= n;
			n--;
			if (n == 1)
			{
				break;
			}
		}
		cout << product;
	}
}


