#include<iostream>
#include<cstring>
#include "String.h"

int main() {
	String test1, test2;
	test1.setString("Batko", 6, 7);
	test2.setString("Safet", 5, 7);
	return 0;
}