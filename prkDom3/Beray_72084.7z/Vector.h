#pragma once
#include "String.h"

template<class T>
class Vector {
	T* deck;
	size_t d_size;
	size_t d_capacity;

	void Resize(size_t newCapacity) {
		T* newDeck = new T[newCapacity];
		if (newCapacity < d_size)
			d_size = newCapacity;

		for (size_t i = 0; i < d_size; i++)
			newDeck[i] = deck[i];

		delete[] deck;
		deck = newDeck;
		d_capacity = newCapacity;
	}
public:
	Vector() {
		d_size = 0;
		d_capacity = 2;
		deck = new T[d_capacity];
	}
	void PushBack(const T& value) {
		if (!(d_capacity >= 30))
		{
			if (d_size >= d_capacity)
				Resize(d_capacity + 1);

			deck[d_size++] = value;
		}
	}
	size_t getSize() const {
		return d_size;
	}
	const T& operator[](size_t index) const {
		return deck[index];
	}
};